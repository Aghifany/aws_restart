import array as arr
#
# myArr = arr.array('i', [1,2,2])
# print(type(myArr))

# # myCharArr = arr.array('u', ['a', 'b', 'c'])
# # print(type(myCharArr))
# #
# print()
# myFruitList = ["apple", "banana", "cherry"]
# print(myFruitList)
# print(type(myFruitList))

# print(myFruitList[2])

#
myFinalAnswerTuple = ("apple", "banana", "pineapple")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))
# print(myFinalAnswerTuple[0])
# print(myFinalAnswerTuple[1])
# print(myFinalAnswerTuple[2])

myFavoriteFruitDictionary = {
  "Akua" : "apple",
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}
print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))